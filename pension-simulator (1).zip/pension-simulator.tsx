"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Image from "next/image"

import { translations } from "./translations"
import { usePensionCalculator } from "./hooks/usePensionCalculator"
import { LanguageToggle } from "./components/LanguageToggle"
import { PensionInput } from "./components/PensionInput"
import { DurationSlider } from "./components/DurationSlider"
import { CapitalDisplay } from "./components/CapitalDisplay"
import { ContactModal } from "./components/ContactModal"
import type { Language } from "./types"
import { DEFAULT_PENSION_AMOUNT, DEFAULT_DURATION, BRAND_COLOR } from "./constants"

export default function PensionSimulator() {
  const [pensionAmount, setPensionAmount] = useState<number>(DEFAULT_PENSION_AMOUNT)
  const [duration, setDuration] = useState<number[]>([DEFAULT_DURATION])
  const [language, setLanguage] = useState<Language>("es")
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  const { calculateRequiredCapital, formatCurrency } = usePensionCalculator()
  const t = translations[language]

  const requiredCapital = calculateRequiredCapital(pensionAmount, duration[0])

  return (
    <div
      className="min-h-screen flex items-center justify-center p-4 bg-cover bg-center bg-no-repeat relative"
      style={{
        backgroundImage: "url('/ocean-background.png')",
      }}
    >
      {/* Overlay with brand colors */}
      <div className="absolute inset-0 bg-gradient-to-br from-slate-800/30 to-emerald-900/20"></div>

      <div className="w-full max-w-md space-y-6 relative z-10">
        <div className="flex justify-center items-center space-x-4">
          <Image
            src="/pension-fi-logo.png"
            alt="Pension Fi Logo"
            width={200}
            height={60}
            className="h-auto drop-shadow-lg"
          />
          <LanguageToggle language={language} onSelectLanguage={setLanguage} />
        </div>

        <Card className="backdrop-blur-sm bg-white/95 shadow-2xl border-t-4" style={{ borderTopColor: BRAND_COLOR }}>
          <CardHeader className="border-b border-gray-100 text-center">
            <CardTitle className="text-slate-700">{t.title}</CardTitle>
            <CardDescription className="text-slate-600">{t.description}</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            <PensionInput
              value={pensionAmount}
              onChange={setPensionAmount}
              label={t.desiredPension}
              placeholder={t.enterAmount}
            />

            <DurationSlider
              value={duration}
              onChange={setDuration}
              label={t.duration}
              yearText={t.year}
              yearsText={t.years}
            />

            <CapitalDisplay label={t.requiredCapital} amount={formatCurrency(requiredCapital)} />

            <ContactModal
              isOpen={isDialogOpen}
              onOpenChange={setIsDialogOpen}
              translations={t.contactForm}
              buttonText={t.getThisPension}
            />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
