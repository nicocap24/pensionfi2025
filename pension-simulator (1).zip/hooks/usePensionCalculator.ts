import { ANNUAL_RETURN_RATE } from "../constants"

export function usePensionCalculator() {
  const calculateRequiredCapital = (pensionAmount: number, years: number): number => {
    const monthlyReturn = Math.pow(1 + ANNUAL_RETURN_RATE, 1 / 12) - 1
    const months = years * 12
    const monthlyPayment = pensionAmount

    if (monthlyPayment <= 0 || months <= 0) return 0

    const presentValue = monthlyPayment * ((1 - Math.pow(1 + monthlyReturn, -months)) / monthlyReturn)
    return presentValue
  }

  const formatCurrency = (amount: number): string => {
    return `$${Math.round(amount).toLocaleString()}`
  }

  return {
    calculateRequiredCapital,
    formatCurrency,
  }
}
