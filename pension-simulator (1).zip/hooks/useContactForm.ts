"use client"

import type React from "react"

import { useState } from "react"
import type { ContactFormData } from "../types"
import { FORM_RESET_DELAY } from "../constants"

export function useContactForm() {
  const [formData, setFormData] = useState<ContactFormData>({ name: "", email: "" })
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleInputChange = (field: keyof ContactFormData, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    console.log("Form submitted:", formData)
    setIsSubmitted(true)

    setTimeout(() => {
      setIsSubmitted(false)
      setFormData({ name: "", email: "" })
    }, FORM_RESET_DELAY)
  }

  const resetForm = () => {
    setFormData({ name: "", email: "" })
    setIsSubmitted(false)
  }

  return {
    formData,
    isSubmitted,
    handleInputChange,
    handleSubmit,
    resetForm,
  }
}
