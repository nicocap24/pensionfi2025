import { BRAND_COLOR, BRAND_COLOR_HOVER } from "../constants"

export const theme = {
  input: {
    focus: {
      ringColor: BRAND_COLOR,
      borderColor: BRAND_COLOR,
      defaultBorder: "#e2e8f0",
    },
  },
  button: {
    gradient: `linear-gradient(to right, #374151, ${BRAND_COLOR})`,
    gradientHover: `linear-gradient(to right, #1f2937, ${BRAND_COLOR_HOVER})`,
  },
  slider: {
    thumbGradient: `linear-gradient(to right, ${BRAND_COLOR}, ${BRAND_COLOR_HOVER})`,
    trackGradient: `linear-gradient(to right, ${BRAND_COLOR}, ${BRAND_COLOR_HOVER})`,
  },
}
