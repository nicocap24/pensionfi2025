"use client"

import { RangeSlider } from "./FormElements"

interface DurationSliderProps {
  value: number[]
  onChange: (value: number[]) => void
  label: string
  yearText: string
  yearsText: string
}

export function DurationSlider({ value, onChange, label, yearText, yearsText }: DurationSliderProps) {
  const formatLabel = (val: number) => `${label}: ${val} ${val === 1 ? yearText : yearsText}`

  return (
    <RangeSlider
      value={value}
      onChange={onChange}
      label={label}
      formatLabel={formatLabel}
      showMinMax={false}
    />
  )
}
