"use client"

import type React from "react"

import { InputWithLabel } from "./FormElements"

interface PensionInputProps {
  value: number
  onChange: (value: number) => void
  label: string
  placeholder: string
}

export function PensionInput({ value, onChange, label, placeholder }: PensionInputProps) {
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const cleanValue = e.target.value.replace(/[^\d]/g, "")
    onChange(Number(cleanValue))
  }

  return (
    <InputWithLabel
      id="pension-amount"
      label={label}
      value={value.toLocaleString()}
      onChange={handleChange}
      placeholder={placeholder}
      prefix="$"
    />
  )
}
