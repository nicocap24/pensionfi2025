"use client"

import type React from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { theme } from "../styles/theme"
import { MIN_DURATION, MAX_DURATION } from "../constants"

interface InputWithLabelProps {
  id: string
  label: string
  value: string | number
  onChange: (e: React.ChangeEvent<HTMLInputElement>) => void
  placeholder?: string
  type?: string
  required?: boolean
  prefix?: string
  className?: string
}

export function InputWithLabel({
  id,
  label,
  value,
  onChange,
  placeholder,
  type = "text",
  required = false,
  prefix,
  className = "",
}: InputWithLabelProps) {
  return (
    <div className="space-y-2">
      <Label htmlFor={id} className="text-slate-700 font-medium text-center block">
        {label}
      </Label>
      <div className="relative">
        {prefix && (
          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-slate-500 font-medium">
            {prefix}
          </span>
        )}
        <Input
          id={id}
          type={type}
          value={value}
          onChange={onChange}
          placeholder={placeholder}
          required={required}
          className={`border-slate-200 focus:ring-2 ${prefix ? "pl-8" : ""} ${className}`}
          style={
            {
              "--tw-ring-color": theme.input.focus.ringColor,
              borderColor: theme.input.focus.defaultBorder,
            } as React.CSSProperties
          }
          onFocus={(e) => {
            e.target.style.borderColor = theme.input.focus.borderColor
          }}
          onBlur={(e) => {
            e.target.style.borderColor = theme.input.focus.defaultBorder
          }}
        />
      </div>
    </div>
  )
}

interface RangeSliderProps {
  value: number[]
  onChange: (value: number[]) => void
  label: string
  min?: number
  max?: number
  step?: number
  formatLabel: (value: number) => string
  showMinMax?: boolean
  minLabel?: string
  maxLabel?: string
}

export function RangeSlider({
  value,
  onChange,
  label,
  min = MIN_DURATION,
  max = MAX_DURATION,
  step = 1,
  formatLabel,
  showMinMax = true,
  minLabel,
  maxLabel,
}: RangeSliderProps) {
  return (
    <div className="space-y-4">
      <Label className="text-base font-semibold text-slate-700 text-center block">{formatLabel(value[0])}</Label>
      <div className="px-3">
        <Slider
          value={value}
          onValueChange={onChange}
          max={max}
          min={min}
          step={step}
          className="w-full [&_[role=slider]]:h-6 [&_[role=slider]]:w-6 [&_[role=slider]]:border-2 [&_[role=slider]]:border-white [&_[role=slider]]:shadow-lg [&>span:first-child]:h-3 [&>span:first-child]:bg-gradient-to-r [&>span:first-child]:from-slate-200 [&>span:first-child]:to-slate-300"
          style={
            {
              "--slider-thumb-bg": theme.slider.thumbGradient,
              "--slider-track-bg": theme.slider.trackGradient,
            } as React.CSSProperties
          }
        />
        <style jsx>{`
          .w-full [role=slider] {
            background: ${theme.slider.thumbGradient} !important;
          }
          .w-full > span:last-child {
            background: ${theme.slider.trackGradient} !important;
          }
        `}</style>
      </div>
      {showMinMax && (
        <div className="flex justify-center text-sm font-medium text-slate-600 px-3 space-x-4">
          <span className="bg-slate-100 text-slate-700 px-2 py-1 rounded-full">{minLabel || min}</span>
          <span className="bg-slate-100 text-slate-700 px-2 py-1 rounded-full">{maxLabel || max}</span>
        </div>
      )}
    </div>
  )
}
