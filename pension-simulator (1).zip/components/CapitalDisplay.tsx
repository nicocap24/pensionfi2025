import { BRAND_COLOR } from "../constants"

interface CapitalDisplayProps {
  label: string
  amount: string
}

export function CapitalDisplay({ label, amount }: CapitalDisplayProps) {
  return (
    <div className="pt-4 border-t border-slate-200">
      <div className="text-center space-y-2">
        <p className="text-sm text-slate-600">{label}</p>
        <p className="text-3xl font-bold" style={{ color: BRAND_COLOR }}>
          {amount}
        </p>
      </div>
    </div>
  )
}
