"use client"

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { useContactForm } from "../hooks/useContactForm"
import type { TranslationContent } from "../types"
import { theme } from "../styles/theme"
import { InputWithLabel } from "./FormElements"

interface ContactModalProps {
  isOpen: boolean
  onOpenChange: (open: boolean) => void
  translations: TranslationContent["contactForm"]
  buttonText: string
}

export function ContactModal({ isOpen, onOpenChange, translations, buttonText }: ContactModalProps) {
  const { formData, isSubmitted, handleInputChange, handleSubmit } = useContactForm()

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogTrigger asChild>
        <button
          className="text-white font-semibold py-3 px-4 rounded-lg transition-all duration-300 transform hover:scale-105 shadow-md hover:shadow-lg mx-auto block"
          style={{
            background: theme.button.gradient,
          }}
          onMouseEnter={(e) => {
            e.currentTarget.style.background = theme.button.gradientHover
          }}
          onMouseLeave={(e) => {
            e.currentTarget.style.background = theme.button.gradient
          }}
        >
          {buttonText}
        </button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="text-slate-700">{translations.title}</DialogTitle>
          <DialogDescription className="text-slate-600">{translations.description}</DialogDescription>
        </DialogHeader>

        {!isSubmitted ? (
          <form onSubmit={handleSubmit} className="space-y-4">
            <InputWithLabel
              id="contact-name"
              label={translations.name}
              value={formData.name}
              onChange={(e) => handleInputChange("name", e.target.value)}
              placeholder={translations.namePlaceholder}
              required
            />

            <InputWithLabel
              id="contact-email"
              type="email"
              label={translations.email}
              value={formData.email}
              onChange={(e) => handleInputChange("email", e.target.value)}
              placeholder={translations.emailPlaceholder}
              required
            />

            <Button
              type="submit"
              className="w-full text-white font-semibold py-2 px-4 rounded-lg transition-all duration-300"
              style={{
                background: theme.button.gradient,
              }}
            >
              {translations.submit}
            </Button>
          </form>
        ) : (
          <div className="text-center py-8">
            <div className="text-6xl mb-4">✅</div>
            <p className="text-lg font-semibold" style={{ color: theme.input.focus.ringColor }}>
              {translations.success}
            </p>
          </div>
        )}
      </DialogContent>
    </Dialog>
  )
}
