"use client"

import { Button } from "@/components/ui/button"
import type { Language } from "../types"
import { BRAND_COLOR } from "../constants"

interface LanguageToggleProps {
  language: Language
  onSelectLanguage: (lang: Language) => void
}

export function LanguageToggle({ language, onSelectLanguage }: LanguageToggleProps) {
  return (
    <div className="flex space-x-2">
      <Button
        onClick={() => onSelectLanguage("es")}
        variant={language === "es" ? "default" : "outline"}
        size="sm"
        className={`flex items-center space-x-1 px-3 py-1 text-sm ${
          language === "es"
            ? "bg-gradient-to-r from-slate-700 to-slate-800 text-white"
            : "bg-white/90 backdrop-blur-sm border-slate-300 hover:bg-white/95 text-slate-700"
        }`}
        style={
          language === "es"
            ? {}
            : {
                borderColor: BRAND_COLOR,
              }
        }
      >
        <span className="mr-1">🇪🇸</span>
        <span>ES</span>
      </Button>

      <Button
        onClick={() => onSelectLanguage("en")}
        variant={language === "en" ? "default" : "outline"}
        size="sm"
        className={`flex items-center space-x-1 px-3 py-1 text-sm ${
          language === "en"
            ? "bg-gradient-to-r from-slate-700 to-slate-800 text-white"
            : "bg-white/90 backdrop-blur-sm border-slate-300 hover:bg-white/95 text-slate-700"
        }`}
        style={
          language === "en"
            ? {}
            : {
                borderColor: BRAND_COLOR,
              }
        }
      >
        <span className="mr-1">🇬🇧</span>
        <span>EN</span>
      </Button>
    </div>
  )
}
