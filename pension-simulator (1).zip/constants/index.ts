export const ANNUAL_RETURN_RATE = 0.08
export const BRAND_COLOR = "#00E5A0"
export const BRAND_COLOR_HOVER = "#00D494"
export const DEFAULT_PENSION_AMOUNT = 4200
export const DEFAULT_DURATION = 5
export const MIN_DURATION = 1
export const MAX_DURATION = 10
export const FORM_RESET_DELAY = 3000
