export type Language = "en" | "es"

export interface ContactFormData {
  name: string
  email: string
}

export interface Translations {
  en: TranslationContent
  es: TranslationContent
}

export interface TranslationContent {
  title: string
  description: string
  desiredPension: string
  duration: string
  year: string
  years: string
  requiredCapital: string
  getThisPension: string
  enterAmount: string
  contactForm: {
    title: string
    description: string
    name: string
    email: string
    namePlaceholder: string
    emailPlaceholder: string
    submit: string
    success: string
  }
}
