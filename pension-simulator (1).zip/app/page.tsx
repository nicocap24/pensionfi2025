import PensionSimulator from "../pension-simulator"

export default function Page() {
  return <PensionSimulator />
}
